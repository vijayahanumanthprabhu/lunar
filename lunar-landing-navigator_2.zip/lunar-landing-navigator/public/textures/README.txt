Drop LOLA heightmaps / albedo textures here (e.g. ldem_80s_20m.png).
Reference them from src/components/canvas/terrain.js.
