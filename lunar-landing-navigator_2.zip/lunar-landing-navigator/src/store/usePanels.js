import { useMemo } from 'react';
import { useMissionStore } from './useMissionStore';
import { getSite } from '../utils/constants';
import { computeMetrics } from '../utils/ephemeris';

/** Derives the 1 or 2 scenario panels (with live metrics) from store state. */
export function usePanels() {
  const siteAId = useMissionStore((s) => s.siteAId);
  const siteBId = useMissionStore((s) => s.siteBId);
  const dateMs = useMissionStore((s) => s.dateMs);
  const dateBMs = useMissionStore((s) => s.dateBMs);
  const comparisonMode = useMissionStore((s) => s.comparisonMode);
  const compareBy = useMissionStore((s) => s.compareBy);

  return useMemo(() => {
    const a = { key: 'A', label: 'Scenario A', site: getSite(siteAId), dateMs };
    const panels = [a];
    if (comparisonMode) {
      panels.push({
        key: 'B', label: 'Scenario B',
        site: getSite(compareBy === 'site' ? siteBId : siteAId),
        dateMs: compareBy === 'date' ? dateBMs : dateMs,
      });
    }
    return panels.map((p) => ({ ...p, metrics: computeMetrics(p.site, p.dateMs) }));
  }, [siteAId, siteBId, dateMs, dateBMs, comparisonMode, compareBy]);
}
