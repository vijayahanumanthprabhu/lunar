import { create } from 'zustand';
import { DEFAULT_SITE_A, DEFAULT_SITE_B } from '../utils/constants';
import { cycleStartMs, DAY_MS } from '../utils/ephemeris';

const START = cycleStartMs(Date.now()) + 3 * DAY_MS;

export const useMissionStore = create((set) => ({
  // Scenario A (always) and scenario B (comparison mode)
  siteAId: DEFAULT_SITE_A,
  siteBId: DEFAULT_SITE_B,
  dateMs: START,           // UTC epoch ms, scenario A
  dateBMs: START + 7 * DAY_MS, // scenario B when compareBy === 'date'
  comparisonMode: false,
  compareBy: 'site',       // 'site' | 'date'
  playing: false,
  speedHoursPerSec: 12,

  setSiteA: (id) => set({ siteAId: id }),
  setSiteB: (id) => set({ siteBId: id }),
  setDate: (ms) => set({ dateMs: ms }),
  setDateB: (ms) => set({ dateBMs: ms }),
  /** Scrub within the current 29.53-day lunar cycle (day offset since new moon). */
  setCycleDay: (day) => set((s) => ({ dateMs: cycleStartMs(s.dateMs) + day * DAY_MS })),
  toggleComparison: () => set((s) => ({ comparisonMode: !s.comparisonMode })),
  setCompareBy: (mode) => set({ compareBy: mode }),
  togglePlay: () => set((s) => ({ playing: !s.playing })),
  setSpeed: (h) => set({ speedHoursPerSec: h }),
  advance: (ms) => set((s) => ({ dateMs: s.dateMs + ms, dateBMs: s.dateBMs + ms })),
}));
