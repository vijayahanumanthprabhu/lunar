import { useEffect } from 'react';
import { useMissionStore } from './useMissionStore';

/** Drives the simulation clock while `playing` is true. Mount once (App). */
export function usePlayback() {
  const playing = useMissionStore((s) => s.playing);
  useEffect(() => {
    if (!playing) return;
    let raf, last = performance.now();
    const tick = (now) => {
      const dt = (now - last) / 1000;
      last = now;
      const { speedHoursPerSec, advance } = useMissionStore.getState();
      advance(dt * speedHoursPerSec * 3_600_000);
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [playing]);
}
