/** Renders 1 panel full-width or 2 panels side by side. */
export default function SplitScreen({ children }) {
  const items = Array.isArray(children) ? children : [children];
  return (
    <div className={`grid h-full min-h-0 gap-px bg-space-700 ${items.length > 1 ? 'grid-cols-2' : 'grid-cols-1'}`}>
      {items}
    </div>
  );
}
