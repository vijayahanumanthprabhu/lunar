import ControlPanel from '../dashboard/ControlPanel';

export default function Sidebar() {
  return (
    <aside className="w-80 shrink-0 overflow-y-auto border-r border-space-700 bg-space-950 p-4">
      <ControlPanel />
    </aside>
  );
}
