import TimeScrubber from '../dashboard/TimeScrubber';

export default function Footer() {
  return (
    <footer className="shrink-0 border-t border-space-700 bg-space-950 px-4 py-3">
      <TimeScrubber />
    </footer>
  );
}
