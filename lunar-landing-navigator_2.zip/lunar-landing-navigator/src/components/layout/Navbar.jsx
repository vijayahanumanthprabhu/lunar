import { useState } from 'react';
import { Moon, Info } from 'lucide-react';
import Modal from '../ui/Modal';

export default function Navbar() {
  const [open, setOpen] = useState(false);
  return (
    <header className="flex h-12 shrink-0 items-center justify-between border-b border-space-700 bg-space-950 px-4">
      <div className="flex items-center gap-2.5">
        <Moon size={18} className="text-sun" />
        <span className="text-sm font-semibold tracking-widest text-slate-100">LUNAR LANDING SITE NAVIGATOR</span>
        <span className="rounded bg-space-700 px-1.5 py-0.5 font-mono text-[10px] text-earth">SPACE APPS 2026</span>
      </div>
      <button onClick={() => setOpen(true)} className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-white">
        <Info size={15} /> About the model
      </button>
      <Modal open={open} onClose={() => setOpen(false)} title="About the model">
        <p>Sun and Earth positions use a simplified geometric ephemeris (mean sub-solar point, optical libration). Terrain horizons are placeholders until LOLA DEMs are wired in. Not for operational planning.</p>
      </Modal>
    </header>
  );
}
