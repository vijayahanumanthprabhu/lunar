export default function Slider({ label, value, min, max, step = 0.01, onChange, valueLabel }) {
  return (
    <label className="block">
      <div className="mb-1.5 flex justify-between text-[11px] uppercase tracking-wider text-slate-400">
        <span>{label}</span>
        <span className="font-mono text-slate-200">{valueLabel}</span>
      </div>
      <input type="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(parseFloat(e.target.value))} />
    </label>
  );
}
