export default function Card({ className = '', children }) {
  return <div className={`rounded-xl border border-space-700 bg-space-900/80 backdrop-blur ${className}`}>{children}</div>;
}
