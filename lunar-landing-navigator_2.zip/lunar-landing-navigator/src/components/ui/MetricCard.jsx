import Card from './Card';

const ACCENT = { sun: 'text-sun', earth: 'text-earth', slate: 'text-slate-100' };

export default function MetricCard({ icon: Icon, label, value, unit, sub, accent = 'slate', badge }) {
  return (
    <Card className="px-3 py-2.5 min-w-[150px] flex-1">
      <div className="flex items-center justify-between text-[10px] uppercase tracking-widest text-slate-400">
        <span className="flex items-center gap-1.5">{Icon && <Icon size={13} />}{label}</span>
        {badge}
      </div>
      <div className={`mt-1 font-mono text-2xl font-semibold ${ACCENT[accent]}`}>
        {value}<span className="ml-1 text-sm text-slate-400">{unit}</span>
      </div>
      {sub && <div className="mt-0.5 text-[11px] text-slate-400">{sub}</div>}
    </Card>
  );
}
