const TONES = {
  cyan: 'bg-earth/10 text-earth border-earth/40',
  amber: 'bg-sun/10 text-sun border-sun/40',
  slate: 'bg-space-700 text-slate-300 border-space-600',
  red: 'bg-red-500/10 text-red-400 border-red-500/40',
  green: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/40',
};
export default function Badge({ tone = 'slate', children }) {
  return (
    <span className={`inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[11px] font-medium uppercase tracking-wider ${TONES[tone]}`}>
      {children}
    </span>
  );
}
