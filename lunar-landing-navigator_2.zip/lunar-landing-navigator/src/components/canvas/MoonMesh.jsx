import { useMemo } from 'react';
import * as THREE from 'three';

export default function MoonMesh({ heightFn, size = 120, segments = 160 }) {
  const geometry = useMemo(() => {
    const g = new THREE.PlaneGeometry(size, size, segments, segments);
    g.rotateX(-Math.PI / 2);
    const pos = g.attributes.position;
    for (let i = 0; i < pos.count; i++) pos.setY(i, heightFn(pos.getX(i), pos.getZ(i)));
    g.computeVertexNormals();
    return g;
  }, [heightFn, size, segments]);

  return (
    <mesh geometry={geometry} receiveShadow castShadow>
      <meshStandardMaterial color="#8d9099" roughness={0.95} metalness={0} />
    </mesh>
  );
}
