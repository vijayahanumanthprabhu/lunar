import { Line, Html } from '@react-three/drei';
import { dirFromAltAz } from './geometry';

const DIST = 80;

export default function EarthVector({ el, az, visible }) {
  const pos = dirFromAltAz(el, az).map((v) => v * DIST);
  return (
    <group>
      <mesh position={pos}>
        <sphereGeometry args={[2.4, 32, 32]} />
        <meshBasicMaterial color="#22D3EE" transparent opacity={visible ? 1 : 0.3} />
        <Html center distanceFactor={90} position={[0, 5, 0]} style={{ pointerEvents: 'none' }}>
          <span className="whitespace-nowrap font-mono text-[10px] text-earth">EARTH {el.toFixed(1)}°</span>
        </Html>
      </mesh>
      <Line points={[[0, 0.3, 0], pos]} color="#22D3EE" lineWidth={1} dashed dashSize={1} gapSize={1} transparent opacity={visible ? 0.7 : 0.2} />
    </group>
  );
}
