const DEG = Math.PI / 180;
/** Local ENU frame -> three.js: x = East, y = Up, -z = North. az from north clockwise. */
export function dirFromAltAz(elDeg, azDeg) {
  const el = elDeg * DEG, az = azDeg * DEG;
  return [Math.cos(el) * Math.sin(az), Math.sin(el), -Math.cos(el) * Math.cos(az)];
}
