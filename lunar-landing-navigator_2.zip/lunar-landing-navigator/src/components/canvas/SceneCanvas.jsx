import { Suspense, useMemo } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, Stars } from '@react-three/drei';
import MoonMesh from './MoonMesh';
import SunVector from './SunVector';
import EarthVector from './EarthVector';
import HorizonRing from './HorizonRing';
import { proceduralHeight } from './terrain';

/**
 * Local-horizon view for one scenario. `heightFn` is the terrain plug-in point:
 * pass a LOLA-backed (x, z) => height function to replace the procedural mesh.
 */
export default function SceneCanvas({ site, metrics, heightFn }) {
  const hf = useMemo(() => heightFn ?? proceduralHeight(site.id, site.terrain), [heightFn, site.id, site.terrain]);
  const { sun, earth, sunUp, earthUp } = metrics;
  return (
    <Canvas shadows dpr={[1, 2]} camera={{ position: [30, 14, 40], fov: 45, near: 0.1, far: 800 }}>
      <color attach="background" args={['#05070d']} />
      <ambientLight intensity={0.05} color="#8ea2c8" />
      <Stars radius={300} depth={60} count={3500} factor={5} fade />
      <Suspense fallback={null}>
        <MoonMesh heightFn={hf} />
        <HorizonRing />
        <SunVector el={sun.el} az={sun.az} visible={sunUp} />
        <EarthVector el={earth.el} az={earth.az} visible={earthUp} />
      </Suspense>
      <OrbitControls target={[0, 2, 0]} enablePan={false} minDistance={8} maxDistance={160} maxPolarAngle={Math.PI * 0.49} />
    </Canvas>
  );
}
