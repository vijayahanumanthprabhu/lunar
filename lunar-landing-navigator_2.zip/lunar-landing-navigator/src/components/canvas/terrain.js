// Terrain "source" contract: a function (x, z) => height (scene units).
// To plug in LOLA: load a heightmap with drei's useTexture, sample it in a new heightFn,
// and pass it to <SceneCanvas heightFn={...} /> -> <MoonMesh heightFn={...} />.
const smooth = (a, b, x) => { const t = Math.min(1, Math.max(0, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
const hash = (s) => [...s].reduce((h, c) => (h * 31 + c.charCodeAt(0)) >>> 0, 7);

export function proceduralHeight(siteId, kind) {
  const p = (hash(siteId) % 1000) / 1000 * 6.28;
  return (x, z) => {
    const r = Math.hypot(x, z);
    const noise = Math.sin(x * 0.21 + p) * Math.cos(z * 0.17 - p) * 1.2 + Math.sin(x * 0.55 + z * 0.43 + p) * 0.35 + Math.sin(x * 1.3 - z * 1.1) * 0.08;
    const base = noise * smooth(4, 20, r); // flat landing pad at origin
    if (kind === 'crater') return base + 9 * smooth(14, 48, r);   // walls rise around you
    if (kind === 'ridge') return base + 3 * Math.sin(x * 0.08 + p) * smooth(10, 40, r);
    if (kind === 'peak') return base - 7 * smooth(14, 50, r);     // ground falls away
    return base * 0.4;
  };
}
