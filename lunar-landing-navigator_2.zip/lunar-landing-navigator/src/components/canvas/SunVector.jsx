import { Line } from '@react-three/drei';
import { dirFromAltAz } from './geometry';

const DIST = 90;

export default function SunVector({ el, az, visible }) {
  const d = dirFromAltAz(el, az);
  const pos = d.map((v) => v * DIST);
  const intensity = visible ? 3.2 * Math.min(1, Math.max(0.15, el / 3)) : 0;
  return (
    <group>
      <directionalLight
        position={d.map((v) => v * 60)} intensity={intensity} color="#fff4d6" castShadow
        shadow-mapSize={[2048, 2048]} shadow-bias={-0.0005}
        shadow-camera-left={-65} shadow-camera-right={65} shadow-camera-top={65} shadow-camera-bottom={-65} shadow-camera-near={1} shadow-camera-far={200}
      />
      <mesh position={pos}>
        <sphereGeometry args={[3.2, 32, 32]} />
        <meshBasicMaterial color="#FBBF24" transparent opacity={visible ? 1 : 0.3} />
      </mesh>
      <Line points={[[0, 0.3, 0], pos]} color="#FBBF24" lineWidth={1} dashed dashSize={2} gapSize={1.5} transparent opacity={visible ? 0.7 : 0.2} />
    </group>
  );
}
