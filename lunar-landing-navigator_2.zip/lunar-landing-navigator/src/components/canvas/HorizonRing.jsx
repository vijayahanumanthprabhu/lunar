import { useMemo } from 'react';
import { Line, Html } from '@react-three/drei';

const R = 55;
const LABELS = [['N', 0, -R], ['E', R, 0], ['S', 0, R], ['W', -R, 0]];

export default function HorizonRing() {
  const pts = useMemo(() => Array.from({ length: 129 }, (_, i) => {
    const a = (i / 128) * Math.PI * 2;
    return [Math.sin(a) * R, 0.2, Math.cos(a) * R];
  }), []);
  return (
    <group>
      <Line points={pts} color="#475569" lineWidth={1} />
      {LABELS.map(([t, x, z]) => (
        <Html key={t} position={[x * 1.08, 0.5, z * 1.08]} center distanceFactor={90} style={{ pointerEvents: 'none' }}>
          <span className="font-mono text-xs font-bold text-slate-400">{t}</span>
        </Html>
      ))}
    </group>
  );
}
