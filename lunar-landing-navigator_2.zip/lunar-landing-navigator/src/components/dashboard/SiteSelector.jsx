import { SITES } from '../../utils/constants';

const GROUPS = [...new Set(SITES.map((s) => s.group))];

export default function SiteSelector({ label, value, onChange }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-[11px] uppercase tracking-wider text-slate-400">{label}</span>
      <select value={value} onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-lg border border-space-600 bg-space-800 px-2.5 py-2 text-sm text-slate-100 outline-none focus:border-earth">
        {GROUPS.map((g) => (
          <optgroup key={g} label={g}>
            {SITES.filter((s) => s.group === g).map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </optgroup>
        ))}
      </select>
    </label>
  );
}
