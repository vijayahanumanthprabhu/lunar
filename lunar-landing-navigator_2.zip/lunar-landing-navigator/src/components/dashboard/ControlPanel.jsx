import { GitCompare, CalendarClock, MapPin } from 'lucide-react';
import { useMissionStore } from '../../store/useMissionStore';
import SiteSelector from './SiteSelector';
import Card from '../ui/Card';
import { getSite } from '../../utils/constants';

const toInput = (ms) => new Date(ms).toISOString().slice(0, 16);
const fromInput = (v) => Date.parse(`${v}:00Z`);

function DateField({ label, ms, onChange }) {
  return (
    <label className="block">
      <span className="mb-1.5 flex items-center gap-1.5 text-[11px] uppercase tracking-wider text-slate-400"><CalendarClock size={12} />{label} (UTC)</span>
      <input type="datetime-local" value={toInput(ms)} onChange={(e) => e.target.value && onChange(fromInput(e.target.value))}
        className="w-full rounded-lg border border-space-600 bg-space-800 px-2.5 py-2 text-sm text-slate-100 outline-none focus:border-earth" />
    </label>
  );
}

export default function ControlPanel() {
  const s = useMissionStore();
  const siteA = getSite(s.siteAId);
  const bySite = s.comparisonMode && s.compareBy === 'site';
  const byDate = s.comparisonMode && s.compareBy === 'date';

  return (
    <div className="space-y-5">
      <section className="space-y-3">
        <h3 className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-widest text-slate-300"><MapPin size={13} /> Landing site</h3>
        <SiteSelector label={bySite ? 'Site A' : 'Site'} value={s.siteAId} onChange={s.setSiteA} />
        {bySite && <SiteSelector label="Site B" value={s.siteBId} onChange={s.setSiteB} />}
        <Card className="p-3 text-xs text-slate-400">
          <div className="font-mono text-slate-200">{siteA.lat.toFixed(2)}°, {siteA.lon.toFixed(2)}° · {siteA.elevationM} m</div>
          <p className="mt-1">{siteA.note}</p>
        </Card>
      </section>

      <section className="space-y-3">
        <h3 className="text-xs font-semibold uppercase tracking-widest text-slate-300">Date & time</h3>
        <DateField label={byDate ? 'Date A' : 'Date'} ms={s.dateMs} onChange={s.setDate} />
        {byDate && <DateField label="Date B" ms={s.dateBMs} onChange={s.setDateB} />}
      </section>

      <section className="space-y-3">
        <h3 className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-widest text-slate-300"><GitCompare size={13} /> Comparison</h3>
        <button onClick={s.toggleComparison}
          className={`w-full rounded-lg border px-3 py-2 text-sm font-medium transition ${s.comparisonMode ? 'border-earth bg-earth/10 text-earth shadow-earth' : 'border-space-600 text-slate-300 hover:border-slate-400'}`}>
          {s.comparisonMode ? 'Split view: ON' : 'Enable split view'}
        </button>
        {s.comparisonMode && (
          <div className="grid grid-cols-2 gap-1 rounded-lg bg-space-800 p-1 text-xs">
            {[['site', 'Site A vs B'], ['date', 'Date A vs B']].map(([k, l]) => (
              <button key={k} onClick={() => s.setCompareBy(k)}
                className={`rounded-md py-1.5 ${s.compareBy === k ? 'bg-space-600 text-white' : 'text-slate-400 hover:text-white'}`}>{l}</button>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
