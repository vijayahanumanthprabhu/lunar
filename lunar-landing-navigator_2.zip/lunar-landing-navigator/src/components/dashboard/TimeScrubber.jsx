import { Play, Pause } from 'lucide-react';
import { useMissionStore } from '../../store/useMissionStore';
import Slider from '../ui/Slider';
import { cycleStartMs, DAY_MS, SYNODIC_DAYS, lunarPhase } from '../../utils/ephemeris';
import { SPEED_OPTIONS } from '../../utils/constants';

export default function TimeScrubber() {
  const dateMs = useMissionStore((s) => s.dateMs);
  const playing = useMissionStore((s) => s.playing);
  const speed = useMissionStore((s) => s.speedHoursPerSec);
  const setCycleDay = useMissionStore((s) => s.setCycleDay);
  const togglePlay = useMissionStore((s) => s.togglePlay);
  const setSpeed = useMissionStore((s) => s.setSpeed);
  const day = (dateMs - cycleStartMs(dateMs)) / DAY_MS;

  return (
    <div className="flex items-center gap-4">
      <button onClick={togglePlay} className="flex h-9 w-9 items-center justify-center rounded-full bg-sun text-space-950 hover:bg-sun-glow">
        {playing ? <Pause size={16} /> : <Play size={16} />}
      </button>
      <div className="flex-1">
        <Slider label="Lunar cycle (days since new moon)" min={0} max={SYNODIC_DAYS} step={0.02} value={day} onChange={setCycleDay}
          valueLabel={`Day ${day.toFixed(1)} / ${SYNODIC_DAYS.toFixed(1)} · phase ${(lunarPhase(dateMs) * 100).toFixed(0)}%`} />
      </div>
      <select value={speed} onChange={(e) => setSpeed(parseFloat(e.target.value))}
        className="rounded-lg border border-space-600 bg-space-800 px-2 py-1.5 text-xs text-slate-200">
        {SPEED_OPTIONS.map((o) => <option key={o.label} value={o.hoursPerSec}>{o.label}</option>)}
      </select>
    </div>
  );
}
