import SceneCanvas from '../canvas/SceneCanvas';
import MetricsHUD from './MetricsHUD';
import Badge from '../ui/Badge';

export default function ScenarioPanel({ panel }) {
  const { label, site, dateMs, metrics } = panel;
  return (
    <section className="relative h-full min-h-0 bg-space-950">
      <SceneCanvas site={site} metrics={metrics} />
      <div className="pointer-events-none absolute left-3 top-3 flex items-center gap-2">
        <Badge tone="cyan">{label}</Badge>
        <span className="text-sm font-semibold text-slate-100">{site.name}</span>
        <span className="font-mono text-xs text-slate-400">{new Date(dateMs).toISOString().slice(0, 16).replace('T', ' ')} UTC</span>
      </div>
      <div className="pointer-events-none absolute inset-x-3 bottom-3"><MetricsHUD metrics={metrics} /></div>
    </section>
  );
}
