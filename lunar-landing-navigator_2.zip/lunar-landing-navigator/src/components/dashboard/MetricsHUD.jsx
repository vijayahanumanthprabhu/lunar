import { Sun, Timer, Radio } from 'lucide-react';
import MetricCard from '../ui/MetricCard';
import Badge from '../ui/Badge';
import { formatDuration } from '../../utils/ephemeris';

export default function MetricsHUD({ metrics }) {
  const { sun, sunUp, sunEventHours, earthUp, earthEventHours, earth } = metrics;
  const eternal = sunUp && sunEventHours == null;
  const dark = !sunUp && sunEventHours == null;

  return (
    <div className="flex flex-wrap gap-2">
      <MetricCard icon={Sun} accent="sun" label="Solar elevation" value={sun.el.toFixed(2)} unit="°"
        sub={`Azimuth ${sun.az.toFixed(0)}°`} badge={<Badge tone={sunUp ? 'amber' : 'slate'}>{sunUp ? 'Lit' : 'Dark'}</Badge>} />
      <MetricCard icon={Timer} accent="sun"
        label={sunUp ? 'Time until sunset' : 'Time until sunrise'}
        value={eternal || dark ? '∞' : formatDuration(sunEventHours)}
        sub={eternal ? 'No sunset within 30 days' : dark ? 'No sunrise within 30 days' : sunUp ? 'Sun drops below horizon mask' : 'Next illumination'} />
      <MetricCard icon={Radio} accent="earth" label="Direct-to-Earth" value={earthUp ? 'YES' : 'NO'}
        sub={earthEventHours == null ? (earthUp ? 'Continuous (30d+)' : 'No window in 30d') : earthUp ? `Signal window: ${formatDuration(earthEventHours)} left` : `Next window in ${formatDuration(earthEventHours)}`}
        badge={<Badge tone={earthUp ? 'cyan' : 'red'}>{earth.el.toFixed(1)}° el</Badge>} />
    </div>
  );
}
