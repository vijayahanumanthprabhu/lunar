// NOTE: coordinates are APPROXIMATE (selenographic, east-positive lon, -180..180).
// Verify against LOLA / NASA Artemis III candidate-region documentation before relying on them.
// horizonDeg is a stand-in for the terrain horizon mask: the Sun/Earth must rise above it to be "visible".
// Replace with a horizon profile computed from LOLA DEMs later.

export const MOON_RADIUS_KM = 1737.4;

export const SITES = [
  { id: 'apollo11', name: 'Apollo 11 (Tranquility)', group: 'Historic', lat: 0.674, lon: 23.473, elevationM: -1900, horizonDeg: 0, terrain: 'mare',
    note: 'Equatorial mare reference site: ~14 Earth-day lunar daylight.' },
  { id: 'shackleton-ridge', name: 'Shackleton Connecting Ridge', group: 'South Pole peaks', lat: -89.45, lon: -137.3, elevationM: 1500, horizonDeg: 0, terrain: 'peak',
    note: 'Near-continuous sunlight; Earth visibility depends on libration.' },
  { id: 'malapert', name: 'Malapert Massif', group: 'South Pole peaks', lat: -85.9, lon: 0.0, elevationM: 4800, horizonDeg: 0, terrain: 'peak',
    note: 'Persistent Earth line-of-sight; often cited as a comms relay candidate.' },
  { id: 'nobile-rim', name: 'Nobile Rim', group: 'Artemis III candidates', lat: -85.2, lon: 53.3, elevationM: 1000, horizonDeg: 0.5, terrain: 'ridge', note: 'Candidate region (approx.).' },
  { id: 'haworth-rim', name: 'Haworth Rim', group: 'Artemis III candidates', lat: -87.5, lon: -5.0, elevationM: 800, horizonDeg: 0.5, terrain: 'ridge', note: 'Candidate region (approx.).' },
  { id: 'faustini-rim', name: 'Faustini Rim A', group: 'Artemis III candidates', lat: -87.3, lon: 77.0, elevationM: 600, horizonDeg: 0.5, terrain: 'ridge', note: 'Candidate region (approx.).' },
  { id: 'de-gerlache', name: 'de Gerlache Rim', group: 'Artemis III candidates', lat: -88.5, lon: -87.1, elevationM: 900, horizonDeg: 0.5, terrain: 'ridge', note: 'Candidate region (approx.).' },
  { id: 'shackleton-floor', name: 'Shackleton Crater Floor (PSR)', group: 'Deep craters', lat: -89.9, lon: 0.0, elevationM: -3900, horizonDeg: 3, terrain: 'crater',
    note: 'Permanently shadowed; Sun never clears the crater wall (>1.54° max elevation at pole).' },
  { id: 'haworth-floor', name: 'Haworth Crater Floor (PSR)', group: 'Deep craters', lat: -87.5, lon: -5.0, elevationM: -3500, horizonDeg: 3, terrain: 'crater',
    note: 'Cold trap candidate; no direct Earth line-of-sight.' },
];

export const DEFAULT_SITE_A = 'shackleton-ridge';
export const DEFAULT_SITE_B = 'shackleton-floor';

export const SPEED_OPTIONS = [
  { label: '1 h/s', hoursPerSec: 1 },
  { label: '12 h/s', hoursPerSec: 12 },
  { label: '1 d/s', hoursPerSec: 24 },
  { label: '3 d/s', hoursPerSec: 72 },
];

export const getSite = (id) => SITES.find((s) => s.id === id) ?? SITES[0];
