// STUB ephemeris: geometric approximations good enough for UI development.
// Swap for SPICE / JPL Horizons / astronomy-engine data for real planning.
const DEG = Math.PI / 180;
export const DAY_MS = 86_400_000;
export const SYNODIC_DAYS = 29.530588853;
export const SYNODIC_MS = SYNODIC_DAYS * DAY_MS;
const NEW_MOON_REF = Date.UTC(2000, 0, 6, 18, 14); // a known new moon

const wrapLon = (l) => ((((l + 180) % 360) + 360) % 360) - 180;

export function lunarPhase(ms) {
  const cycles = (ms - NEW_MOON_REF) / SYNODIC_MS;
  return ((cycles % 1) + 1) % 1; // 0 new, 0.5 full
}

export function cycleStartMs(ms) {
  return NEW_MOON_REF + Math.floor((ms - NEW_MOON_REF) / SYNODIC_MS) * SYNODIC_MS;
}

/** Sub-solar point: new moon -> lon 180, first quarter -> +90E, full -> 0. */
export function subSolarPoint(ms) {
  const t = (ms - NEW_MOON_REF) / DAY_MS;
  return { lat: 1.54 * Math.sin((2 * Math.PI * t) / 346.62), lon: wrapLon(180 - 360 * lunarPhase(ms)) };
}

/** Sub-Earth point = optical libration (±6.7° lat, ±7.9° lon). */
export function subEarthPoint(ms) {
  const t = (ms - NEW_MOON_REF) / DAY_MS;
  return { lat: 6.7 * Math.sin((2 * Math.PI * t) / 27.2122), lon: 7.9 * Math.sin((2 * Math.PI * t) / 27.5546) };
}

/** Elevation/azimuth (deg, az from north clockwise) of a body whose sub-point is `sub`, seen from (lat, lon). */
export function bodyAltAz(latDeg, lonDeg, sub) {
  const p = latDeg * DEG, ps = sub.lat * DEG, dl = (sub.lon - lonDeg) * DEG;
  const sinEl = Math.sin(p) * Math.sin(ps) + Math.cos(p) * Math.cos(ps) * Math.cos(dl);
  const el = Math.asin(Math.max(-1, Math.min(1, sinEl))) / DEG;
  const az = Math.atan2(Math.cos(ps) * Math.sin(dl), Math.cos(p) * Math.sin(ps) - Math.sin(p) * Math.cos(ps) * Math.cos(dl)) / DEG;
  return { el, az: ((az % 360) + 360) % 360 };
}

export const sunAltAz = (site, ms) => bodyAltAz(site.lat, site.lon, subSolarPoint(ms));
export const earthAltAz = (site, ms) => bodyAltAz(site.lat, site.lon, subEarthPoint(ms));

/** Hours until `isUp(ms)` flips, scanning hourly. null = no change within maxHours. */
function hoursToFlip(isUp, ms, maxHours = 30 * 24) {
  const now = isUp(ms);
  for (let h = 1; h <= maxHours; h++) if (isUp(ms + h * 3_600_000) !== now) return h;
  return null;
}

export function computeMetrics(site, ms) {
  const sun = sunAltAz(site, ms);
  const earth = earthAltAz(site, ms);
  const sunUp = sun.el > site.horizonDeg;
  const earthUp = earth.el > site.horizonDeg;
  return {
    sun, earth, sunUp, earthUp,
    sunEventHours: hoursToFlip((t) => sunAltAz(site, t).el > site.horizonDeg, ms),     // sunset if up, sunrise if down
    earthEventHours: hoursToFlip((t) => earthAltAz(site, t).el > site.horizonDeg, ms), // window end / start
  };
}

export function formatDuration(hours) {
  if (hours == null) return '—';
  const d = Math.floor(hours / 24), h = Math.round(hours % 24);
  return d > 0 ? `${d}d ${h}h` : `${h}h`;
}
