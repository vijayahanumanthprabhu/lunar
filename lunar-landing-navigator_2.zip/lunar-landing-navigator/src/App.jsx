import Navbar from './components/layout/Navbar';
import Sidebar from './components/layout/Sidebar';
import Footer from './components/layout/Footer';
import SplitScreen from './components/layout/SplitScreen';
import ScenarioPanel from './components/dashboard/ScenarioPanel';
import { usePanels } from './store/usePanels';
import { usePlayback } from './store/usePlayback';

export default function App() {
  usePlayback();
  const panels = usePanels();
  return (
    <div className="flex h-full flex-col bg-space-950">
      <Navbar />
      <div className="flex min-h-0 flex-1">
        <Sidebar />
        <main className="min-w-0 flex-1">
          <SplitScreen>
            {panels.map((p) => <ScenarioPanel key={p.key} panel={p} />)}
          </SplitScreen>
        </main>
      </div>
      <Footer />
    </div>
  );
}
