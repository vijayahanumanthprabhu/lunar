# Lunar Landing Site Navigator

NASA Space Apps 2026 – interactive South Pole lighting & Earth-visibility planner.

React + Vite · Tailwind · React Three Fiber / drei · Zustand

```bash
npm install
npm run dev
```

## Architecture
- `src/store/useMissionStore.js` – site A/B, UTC date(s), comparison mode (`site` | `date`), playback.
- `src/store/usePanels.js` – derives 1–2 scenario panels + live metrics. `usePlayback.js` drives the clock.
- `src/utils/ephemeris.js` – **stub** sub-solar / libration geometry. Replace with SPICE / Horizons / astronomy-engine.
- `src/utils/constants.js` – curated sites (**approximate coordinates – verify**), `horizonDeg` = terrain mask placeholder.
- `src/components/canvas/` – local ENU scene (x=E, y=Up, -z=N). `terrain.js` is the plug-in point for LOLA heightmaps.

## Next steps
1. Horizon profiles from LOLA DEMs (replace `horizonDeg`) – compute per-azimuth mask, drive sunrise/sunset & comms windows.
2. Load heightmap from `public/textures/` and pass `heightFn` to `SceneCanvas`.
3. Sun disc angular radius (~0.27°) and Earth–Moon distance for better edge-of-disc events.
4. 2D polar map view (south pole stereographic) alongside the 3D horizon view.
