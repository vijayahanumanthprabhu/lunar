/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        space: { 950: '#0B0F19', 900: '#101726', 800: '#171f31', 700: '#243049', 600: '#34425f' },
        sun: { DEFAULT: '#FBBF24', glow: '#F59E0B' },
        earth: { DEFAULT: '#22D3EE', glow: '#06B6D4' },
      },
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'ui-monospace', 'SFMono-Regular', 'monospace'],
      },
      boxShadow: {
        sun: '0 0 24px rgba(251,191,36,0.25)',
        earth: '0 0 24px rgba(34,211,238,0.25)',
      },
    },
  },
  plugins: [],
};
